var express = require("express");
var session = require("express-session");
var hbs = require("hbs");
var bodyParser = require("body-parser");
var mongoClient = require("mongodb").MongoClient;
var authToken = "b3b40691cfbe19a30e9557e935738d2e";
var accountSid = "AC95d45bf3ae0ea163e2f699e84bc61f3e";

var app = express();
const jwt = require("jsonwebtoken");
var auth = require("./routes/auth.js");
var myTrips = require("./routes/myTrips/myFlights")

var checkToken = require("./middleware/check-authToken");
var faq = require('./routes/faqRoute')



app.use(
    bodyParser.urlencoded({
        extended: true
    })
);
app.use(bodyParser.json());
app.use(express.static("public"));
app.set("view engine", "hbs");
app.use('/', faq);

 //var url = "mongodb+srv://ambi1:ambi123@travelp-q0fd8.mongodb.net/?retryWrites=true&w=majority";
 var url="mongodb+srv://ambi1:ambi1234@cluster0-dcofs.mongodb.net/test?retryWrites=true&w=majority";

app.locals.db;

mongoClient.connect(
    url, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    },
   
    function(err, client) {
        if (err) throw err;
        db = client.db("TripPlanner"); //will change db name, when it is created
        console.log("we are connected to mongodb atlas")
        
    }
);

app.locals.ObjectId;
ObjectId = require("mongodb").ObjectID;

app.use(
    session({
        secret: "this is a session!!!",
        resave: true,
        saveUninitialized: true
    })
);
app.get("/packages",function(req,res){
    res.render("packages.hbs",{
    script: "/script.js",
    title: "package"
    });
});



app.post("/packages/build",checkToken, (req, res) => {

    db.collection("mypackages").insertOne({
        userId: ObjectId(req.userData._id),
       
        type: "package",
        packageData: req.body
    },
    (err, result) => {
        if (err) throw err;
        res.json(result);
    }
    );
   
});

app.get("/packages/info",checkToken,(req,res)=>{

    var objectId = require('mongodb').ObjectID;
    //console.log(req.userData._id);
    
    db.collection('mypackages').find({
        "userId":  ObjectId(req.userData._id)
    }).toArray(function(error, result) {
        if (error)
            throw error;
        
        res.render('package.hbs', {
            title: 'mypackage',
            data: result,
            script: '/script.js',
            
        })

        console.log(result);
    })
     
});
app.get("/", function(req, res) {
    var loginButton;
    if (req.session.token) {
        profileBtn = `<div class="button-properties button-3"><a href="/profile" id="heroprofileBtn" style="text-decoration: none; color: wheat">Profile</a></div>`;
        (signupBtn = ""),
        (loginButton = `<a href="/logout"><button class="btn btn-outline-success my-2 my-sm-0" data-toggle="modal"
        data-target="#logOutBtn">Log Out</button></a>`),
        (packagebtn = `<a class="nav-link" href="/packages">build</a>`);
    } else {
        (loginButton = `<button class="btn btn-outline-success my-2 my-sm-0" data-toggle="modal"
        data-target="#loginModal">Login</button>`),
        (signupBtn = `<button class="btn btn-outline-success my-2 my-sm-0" data-toggle="modal"
        data-target="#signupModal">Sign Up</button>`),
        (profileBtn = ""),
        (packagebtn="");
    }
    res.render("home.hbs", {
        title: "Trip Planner",
        loginBtn: loginButton,
        signupBtn: signupBtn,
        profileBtn: profileBtn,
        //data: airlineName,
        packagebtn: packagebtn,
        script: "/script.js"
    });

    
});

// logout the user

app.get("/logout", (req, res) => {
    req.session.destroy();
    res.redirect("/");
});

//login authentication
app.use("/authentication", auth);
app.use('/flightBookings', checkToken, myTrips)

    

// admin API'S
    var adminLog = [{
        username: "admin",
        email: "admin@gmail.com",
        password: "admin"
    },

];


app.post("/login", function(req, res) {
    var flag = false;
    for (var i = 0; i < adminLog.length; i++) {
        if (
            adminLog[i].email == req.body.email &&
            adminLog[i].password == req.body.password
        ) {
            flag = true;
            break;
        }
    }
    if (flag) {
        req.session.username = adminLog.username;
        req.session.loggedIn = true;
        res.redirect("/listfaq");
    } else {
        res.json("Incorrect Credentials")
    }

   
});
app.get("/admin", function(req, res) {
    if (req.session.loggedIn == true) {
        res.render('login');
    } else {
        res.redirect("/listfaq");
    }
});

app.get("/adminlog", function(req, res) {
    res.sendFile(__dirname + '/public/login.html');
})

app.get("/adminlogout", function(req, res) {
    req.session.destroy();
    res.redirect("/faq");
})






app.get("/profile", checkToken, (req, res) => {
    res.render("profile.hbs", {
        title: "User Profile",
        data: req.userData._id
    });
});


app.get("/myaccount", checkToken, (req, res) => {
    db.collection('users').findOne({
        _id: ObjectId(req.userData._id)
    }, (err, result) => {
        if (err) throw err;
        res.render("myAcc.hbs", {
            title: "Account Details",
            data: result,
            script: "/script.js"
        });
    })
});


//custum helper for radio input
hbs.registerHelper('checked', function(value, test) {
    if (value == undefined) return '';
    return value == test ? 'checked' : '';
});


//get list of all hotels 
app.get('/hotels', function(req, res) {
    db.collection('hotels').find().toArray(function(error, result) {
        if (error)
            throw error;
        res.render('hotels.hbs', {
            title: 'hotels',
            data: result,
            script: '/script.js'
        })
    })
});

//city-filter query-working
app.get('/hotels/cityF/:data', function(req, res) {
    var cityId = req.params.data;
    // console.log()
    // var cityId="Delhi";
    var objectId = require('mongodb').ObjectID;

    db.collection('hotels').find({
        "city": cityId
    }).toArray(function(error, result) {
        if (error)
            throw error;
        res.render('hotels.hbs', {
            title: 'hotels',
            data: result,
            script: '/script.js'
        })

    })
})


//working
app.put('/myaccount/acc', checkToken, (req, res) => {
    var proId = req.userData._id
    var updProfile = req.body;
    var objectId = require('mongodb').ObjectId
    db.collection('users').update({
        "_id": new objectId(proId)
    }, {
        $set: updProfile
    }, function(error, result) {
        if (error)
            throw error;
        console.log(result);
        // res.json(result);

    })
})


app.put('/hotels/book/', checkToken, (req, res) => {
        var proId = req.userData._id
            
        db.collection('trips').insert(req.body, function(error, result) {

            if (error)
                throw error;
            db.collection('trips').update(req.body, {
                $set: {
                    "userid": proId
                }
            }, {
                upsert: true
            })
            console.log(result);
            
        })
    })
    

app.get('/hotels/bookings/', checkToken, (req, res) => {
    

    var objectId = require('mongodb').ObjectID;
    
    db.collection('trips').find({
        "userid": req.userData._id
    }).toArray(function(error, result) {
        if (error)
            throw error;
        
        res.render('bookingC.hbs', {
            title: 'Confirm Booking',
            data: result,
            script: '/script.js'
        })

        console.log(result);
    })

})

//packages
app.get('/holiday', function(req, res) {
    res.render('holidays.hbs', {
        title: 'Holidays & Travel Packages',
        script: '/script.js'
    });
})



//book package
app.put('/holidays/submit/', checkToken, (req, res) => {
    var proId = req.userData._id
        
    db.collection('holidays').insert(req.body, function(error, result) {

        if (error)
            throw error;
        db.collection('holidays').update(req.body, {
            $set: {
                "userid": proId
            }
        }, {
            upsert: true
        })
        console.log(result);


    })
})






app.listen(3000, function() {
    console.log("Listening on port 3000");
});